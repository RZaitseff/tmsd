Sample Spring Boot Web Application with JSP
====

before all: install h2 driver to local maven repository
---

     ./mvn install:install-file -Dfile="lib\h2.jar" -DgroupId="com.h2database" -DartifactId=h2 -Dversion="2.2.224"  -Dpackaging=jar


Building and running
---

    ./mvnw clean spring-boot:run


or

    ./mvnw clean package
    java -jar target/report-tmsd.war
    
    
Verification:

    curl -i -I http://localhost:8082/                                                                                      śro, 29 sie 2018, 14:36:14 
    HTTP/1.1 200 
