create DATABASE scdt;

create user scdt WITH PASSWORD 'admin';

GRANT ALL PRIVILEGES ON DATABASE scdt TO scdt;
GRANT USAGE ON SCHEMA public TO scdt;
GRANT ALL ON SCHEMA public TO scdt;
GRANT ALL ON ALL TABLES IN SCHEMA public TO scdt;

-- create service meta
-- (
--     id      bigint generated always as identity,
--     file    text,
--     fields  text[],
--     "service" text
-- );
--
-- create service import
-- (
--     id     bigint generated always as identity,
--     file   TEXT not null,
--     "service" text,
--     date   timestamp not null default now(),
--     storno boolean,
--     ref   bigint,
--     comments text
-- );
--
-- create service block
-- (
--     id   integer not null constraint block_pk primary key,
--     name text unique not null
-- );
--
-- create service if not exists tribe
-- (
--     id       integer not null constraint tribe_pk primary key,
--     block_id integer not null constraint tribe_block_fk references block,
--     name     text not null
-- );
--
-- create service if not exists division
-- (
--     id       integer not null constraint division_pk primary key,
--     name     text not null
-- );
--
-- create service if not exists department
-- (
--     id          integer not null constraint department_pk primary key,
--     division_id integer not null constraint department_division_fk references division,
--     name        text not null
-- );
--
-- create service if not exists subdepartment
-- (
--     id          integer not null constraint subdepartment_pk primary key,
--     division_id integer not null constraint subdepartment_division_fk references division,
--     department_id integer not null constraint subdepartment_department_fk references department,
--     name     text not null
-- );
--
-- create service user_info
-- (
--     user_id       integer not null constraint user_info_pk primary key,
--     user_login    text,
--     email         text,
--     sudir         text,
--     user_name     text,
--     block_id      integer not null constraint user_info_block_fk references block,
--     tribe_id      integer not null constraint user_info_tribe_fk references tribe,
--     division_id integer constraint user_info_division_fk references division,
--     department_id integer constraint user_info_department_fk references department,
--     subdepartment_id integer constraint user_info_subdepartment_fk references subdepartment
-- );
--
-- create service "Account"
-- (
--     id       bigint generated always as identity constraint "Account_pk" primary key,
--     type     account_type not null,
--     account  text,
--     owner_id integer constraint "Account_user_fk" references user_info
-- );
--
-- comment on column "Account".owner_id is 'Пользователь либо АС';
--
create table  scdt.public.Replica
(
    id            bigint generated always as identity
                    constraint replica_pk primary key,
    date          timestamp not null default now(),
    source           text,
    "user"           text,
    host             text,
    alias            text,
    database         text,
    "table"          text,
    table_path       text,
    received_data    float,
    proxy_user       text,
    user_name        text,
    block            text,
    tribe            text,
    division         text,
    department       text,
    sub_department   text,
    source_name      text,
    index            text,
    replica_name     text,
    replica_ke       text,
    source_ke        text,
    "serviceManager" text,
    owner            text,
    owner_block      text,
    owner_department text,
    status           text
);
comment on table scdt.public.replica is 'Реплики источников';


-- create service "Teradata_CPU"
-- (
--     id             bigint generated always as identity constraint "Teradata_CPU_pk" primary key,
--     user_id        integer      not null constraint "Teradata_CPU_user_fk" references user_info,
--     account_type   account_type not null,
--     bb             text,
--     owner_id       integer,
--     consumed_cpu   real,
--     finalwdname    text,
--     profilename    text,
--     db_path        text,
--     last_activity  timestamp,
--     cntrl          text,
--     tribe_erm_id   integer,
--     department_ids integer[]
-- );
--
