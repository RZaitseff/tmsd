SELECT
    c.relname as table,
    (
        SELECT
            td.description
        FROM
            pg_catalog.pg_description td
        WHERE
              td.objoid = a.attrelid
          AND td.objsubid = 0
    ) as description
FROM
    pg_catalog.pg_attribute a
        JOIN pg_catalog.pg_class c ON a.attrelid = c.oid
        JOIN pg_catalog.pg_namespace n ON c.relnamespace = n.oid
WHERE
        a.attnum = 1
  AND n.nspname = 'public'
  and c.reltype <> 0
  and c.relname = ?
ORDER BY
    c.relname,
    a.attnum
;

-- Размер таблицы
SELECT pg_relation_size('TransformMap') as size;

--  Количество записей
SELECT count(*) FROM TransformMap as count;
