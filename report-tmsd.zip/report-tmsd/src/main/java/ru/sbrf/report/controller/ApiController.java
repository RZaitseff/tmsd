package ru.sbrf.report.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ru.sbrf.report.entity.DataBaseInfo;
import ru.sbrf.report.entity.SchemaInfo;
import ru.sbrf.report.entity.TableMeta;
import ru.sbrf.report.entity.target.TransformMap;
import ru.sbrf.report.service.Comparator;
import ru.sbrf.report.service.DbInfo;
import ru.sbrf.report.service.Validator;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

//@CrossOrigin(origins = "http://localhost:8082")
@RestController
@RequestMapping("/api")
public class ApiController {

    @Autowired
    private Validator validator;

    @Autowired
    private Comparator comparator;

    @Autowired
    private DbInfo dbInfo;

    private boolean isDbInService(String db) {
        if (db.equalsIgnoreCase("TMSD")  ||
                db.equalsIgnoreCase("CSDT") ||
                db.equalsIgnoreCase("REPORT")) {
            return true;
        } else {
            return false;
        }
    }

    @GetMapping("/db/{db}")
    public ResponseEntity<DataBaseInfo> getDbInfo(@PathVariable String db) {
        return new ResponseEntity<>(dbInfo(db), HttpStatus.OK);
    }

    public DataBaseInfo dbInfo(String db) {
            DataBaseInfo dbInfo = new DataBaseInfo(db);
            dbInfo.setSize(this.dbInfo.getDbSize(db));
        if (isDbInService(db)) {
            List schemaList = this.dbInfo.getDbSchemas(db);
            for (Object schema : schemaList) {
                SchemaInfo schemaInfo = new SchemaInfo((String) schema);
                dbInfo.getSchemas().add(schemaInfo);
                for (Object table : this.dbInfo.getDbTables(db, (String) schema)) {
                    schemaInfo.getTables().add(this.dbInfo.readTableInfo(db, (String) schema, (String) table));
                }
            }
        } else {
            dbInfo.setSize("Сведения о БД " + db + " не разглашаются");
        }
        return dbInfo;
    }

    @GetMapping("/db/{db}/{schema}/{table}")
    public ResponseEntity<TableMeta> getDbSchemaInfo(
            @PathVariable String db, @PathVariable String schema, @PathVariable String table) {
        return new ResponseEntity<>(dbInfo.readTableMeta(db, schema, table), HttpStatus.OK);
    }

    @GetMapping("/transform")
    public ResponseEntity<List<TransformMap>> getAllTableMeta() {
        return new ResponseEntity<>(validator.readAllTransformMap(), HttpStatus.OK);
    }
    @GetMapping("/meta/{table}")
    public ResponseEntity<Map<String, TableMeta>> getTable(@PathVariable String table) {
        Map<String, TableMeta> cortege = new HashMap<>();
        cortege.put("csdt", comparator.getEntityMetaCsdt(table));
        cortege.put("report", validator.readTableMeta(table));
        return new ResponseEntity<>(cortege, HttpStatus.OK);
    }
}
