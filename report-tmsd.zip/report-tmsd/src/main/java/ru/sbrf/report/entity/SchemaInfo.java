package ru.sbrf.report.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class SchemaInfo {
    protected String name;
    protected List<TableInfo> tables;

    public SchemaInfo(String name) {
        this.name = name;
        this.tables = new ArrayList<>();
    }

    public String tableListString() {
        StringBuilder accumulator = new StringBuilder();
        for (TableInfo table: tables) {
            accumulator.append(table.toString()).append(", ");
        }
        return accumulator.substring(0, accumulator.length() - 2);
    }

    public String toString() {
        return "Schema info: name = " + name
                          + "tables = [" + tableListString() + "]";
    }
}
