package ru.sbrf.report.entity.csdt;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.Comment;

import java.sql.Timestamp;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "replica")@Comment("Реплики источников")
public class Replica {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Comment("Дата")
    private Timestamp date;
    @Comment("Источник")
    private String source;
    @Comment("Пользователь")
    private String user;
    @Comment("Ф.И.О. сотрудника")
    private String userName;
    @Comment("Хост пользователя")
    private String host;
    @Comment("Алиас")
    private String alias;
    @Comment("База данных")
    private String database;
    @Comment("Таблица")
    private String table;
    @Comment("Путь к таблице")
    private String tablePath;
    @Comment("Количество полученных с источника Гбайт")
    private Float receivedData;
    @Comment("Прокси Пользователь")
    private String proxyUser;
    @Comment("Блок")
    private String block;
    @Comment("Трайб")
    private String tribe;
    @Comment("Подразделение 1 уровня")
    private String division;
    @Comment("Подразделение 2 уровня")
    private String department;
    @Comment("Подразделение 3 уровня")
    private String subDepartment;
// -----------------------------

    @Comment("Наименование источника")
    private String sourceName;
    @Comment("Индекс")
    private String index;
    @Comment("КЭ Реплики")
    private String replicaKe;
    @Comment("КЭ источника")
    private String sourceKe;
    @Comment("Наименование")
    private String replicaName;
    @Comment("Менеджер It-услуги")
    private String serviceManager;
    @Comment("Владелец")
    private String owner;
    @Comment("Блок владельца")
    private String ownerBlock;
    @Comment("Подразделение владельца")
    private String ownerDepartment;
    @Comment("Статус")
    private String status;

}
