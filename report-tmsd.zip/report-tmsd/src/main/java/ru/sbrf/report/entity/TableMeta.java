package ru.sbrf.report.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class TableMeta extends TableInfo {
    protected List fields;

    public TableMeta(String table, String description) {
        super(table, description);
    }

    private String getFieldsAsString() {
        StringBuilder accumulator = new StringBuilder();
        for (Object fieldObject: fields) {
            Field field = (Field) fieldObject;
            accumulator.append(field.getField()).append(": ").append(field.getType())
                    .append(" -> ").append(field.getDescription()).append(", ");
        }
        return accumulator.toString();
    }
    public String toString() {
        return "Table Meta info: [table=" + name + ", description=" + description
                + ", size=" + size + ", count=" + count
                + ", fields=(" + getFieldsAsString() + ")]";
    }
}
