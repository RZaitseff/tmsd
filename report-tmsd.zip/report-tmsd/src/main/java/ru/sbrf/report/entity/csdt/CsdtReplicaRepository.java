package ru.sbrf.report.entity.csdt;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

@Component
@Qualifier("csdtReplicaRepository")
public interface CsdtReplicaRepository extends JpaRepository<Replica, Long> {
}
