package ru.sbrf.report.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import ru.sbrf.report.entity.DataBaseInfo;
import ru.sbrf.report.entity.SchemaInfo;
import ru.sbrf.report.service.DbInfo;
import ru.sbrf.report.service.LoginService;

import java.util.List;

@Controller
@SessionAttributes("name")
public class LoginController {

    @Autowired
    LoginService loginService;

    @RequestMapping(value="/login", method = RequestMethod.GET)
    public String showLoginPage(ModelMap model){
        return "login";
    }

    @RequestMapping(value="/login", method = RequestMethod.POST)
    public String showWelcomePage(ModelMap model, @RequestParam String name, @RequestParam String password){

        boolean isValidUser = loginService.validateUser(name, password);

        if (!isValidUser) {
            model.put("errorMessage", "Invalid Credentials");
            return "login";
        }

        model.put("name", name);
        model.put("password", password);

        return "welcome";
    }

    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String showIndexPage(ModelMap model) {
        model.put("name", "DUMMY");
        return "index";
    }

    @RequestMapping(value = "/fail", method = RequestMethod.GET)
    public String showFailPage(ModelMap model) {
        model.put("name", "DUMMY");
        model.put("status", "Error");
        model.put("error", "Something wrong");
        return "error";
    }

//    private String getLoggedinUserName() {
//        Object principal = SecurityContextHolder.getContext()
//                .getAuthentication().getPrincipal();
//
//        if (principal instanceof UserDetails) {
//            return ((UserDetails) principal).getUsername();
//        }
//
//        return principal.toString();
//    }

}
