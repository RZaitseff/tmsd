package ru.sbrf.report.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class TableInfo {
    protected String name;
    protected String description;
    protected String size;
    protected Long count;

    public TableInfo(String name, String description) {
        this.name = name;
        this.description = description;
    }
    public String toString() {
        return "Table info: [table=" + name + ", description=" + description
                + ", size=" + size + ", count=" + count + "]";
    }
}
