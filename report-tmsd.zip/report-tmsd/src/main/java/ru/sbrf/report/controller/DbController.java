package ru.sbrf.report.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import ru.sbrf.report.entity.DataBaseInfo;
import ru.sbrf.report.entity.SchemaInfo;
import ru.sbrf.report.service.DbInfo;

import java.util.List;

@Controller
@SessionAttributes("name")
public class DbController {

    @Autowired
    private DbInfo dbInfo;

    @GetMapping("/db/{db}")
    public String getDbInfo(ModelMap model, @PathVariable String db) {
        model.put("db", db);
        model.put("info", dbInfo(db));
        return "dbInfo";
    }

    public DataBaseInfo dbInfo(String db) {
        DataBaseInfo dbInfo = new DataBaseInfo(db);
        dbInfo.setConnections(this.dbInfo.getDbConnections(db));
        dbInfo.setSize(this.dbInfo.getDbSize(db));
        List schemaList = this.dbInfo.getDbSchemas(db);
        for (Object schema : schemaList) {
            SchemaInfo schemaInfo = new SchemaInfo((String) schema);
            dbInfo.getSchemas().add(schemaInfo);
            for (Object table : this.dbInfo.getDbTables(db, (String) schema)) {
                schemaInfo.getTables().add(this.dbInfo.readTableInfo(db, (String) schema, (String) table));
            }
        }
        return dbInfo;
    }

    @GetMapping("/db/{db}/{schema}/{table}")
    public String getDbInfo(ModelMap model
            , @PathVariable String db
            , @PathVariable String schema
            , @PathVariable String table)
    {
        model.put("db", db);
        model.put("schema", schema);
        model.put("table", table);
        model.put("info", dbInfo.readTableMeta(db, schema, table));
        return "tableInfo";
    }


}
