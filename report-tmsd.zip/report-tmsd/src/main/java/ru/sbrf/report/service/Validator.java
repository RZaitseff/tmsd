package ru.sbrf.report.service;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.metamodel.EntityType;
import jakarta.persistence.metamodel.Metamodel;
import org.hibernate.annotations.Comment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import ru.sbrf.report.entity.Field;
import ru.sbrf.report.entity.TableField;
import ru.sbrf.report.entity.TableMeta;
import ru.sbrf.report.entity.target.*;

import java.util.ArrayList;
import java.util.List;

@Service
public class Validator {
    private EntityManager reportEntityManager;
    @Autowired
    public void setReportEntityManager(@Qualifier("reportEntityManager") EntityManager reportEntityManager) {
        this.reportEntityManager = reportEntityManager;
    }

    private EntityManager csdtEntityManager;
    @Autowired
    public void setCsdtEntityManager(@Qualifier("csdtEntityManager") EntityManager csdtEntityManager) {
        this.csdtEntityManager = csdtEntityManager;
    }

    private Metamodel csdtMetamodel;
    @Autowired
    public void setCsdtMetamodel(@Qualifier("csdtMetamodel") Metamodel csdtMetamodel) {
        this.csdtMetamodel = csdtMetamodel;
    }

    private Metamodel reportMetamodel;
    @Autowired
    public void setReportMetamodel(@Qualifier("reportMetamodel") Metamodel reportMetamodel) {
        this.reportMetamodel = reportMetamodel;
    }

    @Autowired
    private TransformMapDAO transformMapDAO;

    public TransformMap readTransformBySource(String source) {
        TypedQuery<TransformMap> query = reportEntityManager.createQuery(
                "SELECT m FROM TransformMap m WHERE m.source=:source", TransformMap.class);

        return query.setParameter("source", source).getSingleResult();
    }

    public TableMeta readEntityMeta(String entityName) {
        Class<?> entityClass = null;
        for (EntityType<?> e: reportEntityManager.getMetamodel().getEntities()) {
            if (e.getName().equalsIgnoreCase(entityName)) {
                entityClass = e.getJavaType();
                break;
            }
        }
        if (entityClass == null) return null;

        TableMeta meta = new TableMeta();
        meta.setName(entityClass.getName());
        meta.setDescription(entityClass.getAnnotation(Comment.class).value());
        meta.setFields(new ArrayList<>());
        for (java.lang.reflect.Field field : entityClass.getDeclaredFields()) {
            String fieldName, fieldAlias;
            Class<?> fieldType;
            if (field.isAnnotationPresent(Comment.class)) {
                fieldName = field.getName();
                fieldType = field.getType();
                fieldAlias = field.getAnnotation(Comment.class).value();
                Field entityField = new Field(fieldName, fieldType.getSimpleName(), fieldAlias);
                meta.getFields().add(entityField);
            }
        }

        return meta;
    }


    public TableMeta readTableMeta(String tableName) {
        Query tableQuery = reportEntityManager.createNativeQuery(
                "SELECT\n" +
                        "    c.relname as table,\n" +
                        "    (\n" +
                        "        SELECT\n" +
                        "            td.description\n" +
                        "        FROM\n" +
                        "              pg_catalog.pg_description td\n" +
                        "        WHERE\n" +
                        "                td.objoid = a.attrelid\n" +
                        "          AND td.objsubid = 0\n" +
                        "    ) as description\n" +
                        "FROM\n" +
                        "    pg_catalog.pg_attribute a\n" +
                        "        JOIN pg_catalog.pg_class c ON a.attrelid = c.oid\n" +
                        "        JOIN pg_catalog.pg_namespace n ON c.relnamespace = n.oid\n" +
                        "WHERE\n" +
                        "        a.attnum = 1\n" +
                        "  AND n.nspname = 'public'\n" +
                        "  and c.reltype <> 0\n" +
                        "  and c.relname = :table\n" +
                        "ORDER BY\n" +
                        "    c.relname,\n" +
                        "    a.attnum\n");

        Object[] result = (Object[])tableQuery.setParameter("table", tableName.toLowerCase()).getSingleResult();
        TableMeta tableMeta = new TableMeta((String)result[0], (String)result[1]);

        TypedQuery<TableField> fieldQuery = (TypedQuery<TableField>)reportEntityManager.createNativeQuery(
                "        SELECT\n" +
//                        "            a.attnum as id,\n" +
                        "            a.attname as field,\n" +
                        "            pt.typname as type,\n" +
                        "            ad.description as description,\n" +
                        "            CASE WHEN a.atttypmod = -1 THEN NULL ELSE a.atttypmod END as length,\n" +
                        "            a.attnotnull as \"notNULL\",\n" +
                        "            CASE WHEN a.attnum IN(\n" +
                        "                SELECT UNNEST(cn.conkey)\n" +
                        "                FROM pg_catalog.pg_constraint cn\n" +
                        "                WHERE\n" +
                        "                        cn.conrelid = a.attrelid\n" +
                        "                    AND cn.contype LIKE 'p'\n" +
                        "            ) THEN true END as key\n" +
                        "        FROM pg_catalog.pg_attribute a\n" +
                        "            JOIN pg_catalog.pg_type pt ON a.atttypid = pt.oid\n" +
                        "            JOIN pg_catalog.pg_class c ON a.attrelid = c.oid\n" +
                        "            JOIN pg_catalog.pg_namespace n ON c.relnamespace = n.oid\n" +
                        "            LEFT JOIN pg_catalog.pg_description ad ON ad.objoid = a.attrelid\n" +
                        "                AND ad.objsubid = a.attnum\n" +
                        "        WHERE\n" +
                        "                a.attnum > 0\n" +
                        "            AND n.nspname = 'public'\n" +
                        "            and c.reltype <> 0\n" +
                        "            and c.relname = :table\n" +
                        "        ORDER BY\n" +
                        "            c.relname,\n" +
                        "            a.attnum\n", TableField.class
        );

        List<TableField> fields = fieldQuery.setParameter("table", tableName.toLowerCase()).getResultList();
        tableMeta.setFields(fields);
        return tableMeta;
    }

   public List<TransformMap> readAllTransformMap() {
        return transformMapDAO.getAll();
}

}
