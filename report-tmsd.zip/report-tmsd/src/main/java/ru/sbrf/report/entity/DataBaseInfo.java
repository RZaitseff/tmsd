package ru.sbrf.report.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class DataBaseInfo {
    protected String name;
    protected String size;
    protected List<SchemaInfo> schemas;
    protected List connections;

    public DataBaseInfo(String name) {
        this.name = name;
        this.schemas = new ArrayList<>();
    }

    public String schemaListString() {
        StringBuilder accumulator = new StringBuilder();
        for (SchemaInfo schema: schemas) {
            accumulator.append(schema.toString()).append(", ");
        }
        return accumulator.substring(0, accumulator.length() - 2);
    }

    public String toString() {
        return "Table info: db = " + name + ", size = " +size
                + "schema List = [" + schemaListString() + "]";
    }
}
