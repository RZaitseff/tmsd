package ru.sbrf.report.service;

import jakarta.persistence.EntityManager;
import jakarta.persistence.metamodel.EntityType;
import jakarta.persistence.metamodel.Metamodel;
import org.hibernate.annotations.Comment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.sbrf.report.entity.Field;
import ru.sbrf.report.entity.TableMeta;
import ru.sbrf.report.entity.target.TransformMapDAO;
import ru.sbrf.report.entity.target.TransformMapRepository;

import java.util.ArrayList;

@Service
public class Comparator {
    private Metamodel csdtMetamodel;
    @Autowired
    public void setCsdtMetamodel(@Qualifier("csdtMetamodel") Metamodel csdtMetamodel) {
        this.csdtMetamodel = csdtMetamodel;
    }

    private Metamodel reportMetamodel;
    @Autowired
    public void setReportMetamodel(@Qualifier("reportMetamodel") Metamodel reportMetamodel) {
        this.reportMetamodel = reportMetamodel;
    }

    @Autowired
    private LocalContainerEntityManagerFactoryBean csdtEntityManagerFactory;

    @Autowired
    private LocalContainerEntityManagerFactoryBean reportEntityManagerFactory;

    @Autowired
    private EntityManager reportEntityManager;

    @Autowired
    private TransformMapRepository transformMapRepository;

    @Autowired
    private TransformMapDAO transformMapDAO;

    @Transactional(transactionManager="csdtTransactionManager")
    public TableMeta getEntityMetaCsdt(String entityName)
    {
        return readEntityMeta(csdtMetamodel, entityName);
    }

    @Transactional(transactionManager="reportTransactionManager")
    public TableMeta getEntityMetaReport(String entityName)
    {
        return readEntityMeta(reportMetamodel, entityName);
    }

    public TableMeta readEntityMeta(Metamodel metaModel, String entityName) {
        Class<?> entityClass = null;
        for (EntityType<?> e: metaModel.getEntities()) {
            if (e.getName().equalsIgnoreCase(entityName)) {
                entityClass = e.getJavaType();
                break;
            }
        }
        if (entityClass == null) return null;

        TableMeta meta = new TableMeta();
        meta.setName(entityClass.getName());
        meta.setDescription(entityClass.getAnnotation(Comment.class).value());
        meta.setFields(new ArrayList<Field>());
        for (java.lang.reflect.Field field : entityClass.getDeclaredFields()) {
            String fieldName, fieldType, fieldAlias;
            if (field.isAnnotationPresent(Comment.class)) {
                fieldName = field.getName();
                fieldType = field.getType().getSimpleName();
                fieldAlias = field.getAnnotation(Comment.class).value();
                Field entityField = new Field(fieldName, fieldType, fieldAlias);
                meta.getFields().add(entityField);
            }
        }

        return meta;
    }

}
