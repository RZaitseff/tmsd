package ru.sbrf.report.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Field {
    protected String field;
    protected String type;
    protected String description;

    public String toString() {
        return "TableField info: [" + field + ": " + type + " -> " + description + "]";
    }
}
