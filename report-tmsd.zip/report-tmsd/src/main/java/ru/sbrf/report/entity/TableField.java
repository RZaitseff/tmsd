package ru.sbrf.report.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import ru.sbrf.report.entity.Field;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TableField extends Field {
    protected Integer length;
    protected Boolean notNULL;
    protected Boolean key;

    public TableField(String field, String type, String description,
                      Integer length, Boolean notNULL, Boolean key) {
        super(field, type, description);
        this.length = length;
        this.notNULL = notNULL;
        this.key = key;
    }

    public String toString() {
        return "Field info: [" + field + ": " + type + " -> " + description + "]";
    }
}
