package ru.sbrf.report.entity;

import jakarta.persistence.EntityManager;
import org.springframework.transaction.annotation.Transactional;

import java.io.Serializable;
import java.util.List;

public abstract class GenericDAO<T extends Serializable> {

    protected Class<T> clazz;
    protected EntityManager entityManger;

    public GenericDAO(EntityManager entityManger, Class<T> clazz) {
        this.entityManger = entityManger;
        this.clazz = clazz;
    }
    public void setClazz(Class<T> clazzToSet) {
        this.clazz = clazzToSet;
    }

    public T findById(Integer id) {
        return entityManger.find(this.clazz, id);
    }

    public List<T> getAll() {
        return entityManger.createQuery("from " + this.clazz.getName()).getResultList();
    }

    @Transactional
    public void save(T entity) {
        entityManger.persist(entity);
    }
}
