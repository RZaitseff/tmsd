package ru.sbrf.report.service;

import org.springframework.stereotype.Service;

@Service
public class LoginService {

    public boolean validateUser(String userid, String password) {
        return userid.equalsIgnoreCase("dummy")
                && password.equalsIgnoreCase("test");
    }

}
