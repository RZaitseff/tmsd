package ru.sbrf.report.config;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.metamodel.Metamodel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.init.DataSourceInitializer;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;
import java.util.Objects;
import java.util.Properties;

/**
 * @author Ramesh Fadatare
 *
 */
@Configuration
@EnableJpaRepositories(
        basePackages = "ru.sbrf.report.entity.csdt",
        entityManagerFactoryRef = "csdtEntityManagerFactory",
        transactionManagerRef = "csdtTransactionManager"
)
public class CsdtDataSourceConfig {

    @Autowired
    private Environment env;

    @Primary
    @Bean(name="csdtDataSourceProperties")
    @ConfigurationProperties(prefix="spring.datasource.scdt")
    protected DataSourceProperties csdtDataSourceProperties() {
        return new DataSourceProperties();
    }

    @Primary
    @Bean(name="csdtDataSource")
    public DataSource csdtDataSource(
        @Qualifier("csdtDataSourceProperties") DataSourceProperties csdtDataSourceProperties) {
        return DataSourceBuilder.create()
                .driverClassName(csdtDataSourceProperties.getDriverClassName())
                .url(csdtDataSourceProperties.getUrl())
                .username(csdtDataSourceProperties.getUsername())
                .password(csdtDataSourceProperties.getPassword())
                .build();
    }

    @Primary
    @Bean(name="csdtEntityManagerFactory")
    public LocalContainerEntityManagerFactoryBean csdtEntityManagerFactory(
            @Qualifier("csdtDataSource") DataSource csdtDataSource) {
        LocalContainerEntityManagerFactoryBean factory = new LocalContainerEntityManagerFactoryBean();
        factory.setDataSource(csdtDataSource);
        factory.setPackagesToScan(new String[]{"ru.sbrf.report.entity.csdt"});
        factory.setJpaVendorAdapter(new HibernateJpaVendorAdapter());

        Properties jpaProperties = new Properties();
        jpaProperties.put("hibernate.hbm2ddl.auto", env.getProperty("spring.jpa.hibernate.ddl-auto"));
        jpaProperties.put("hibernate.show-sql", env.getProperty("spring.jpa.show-sql"));
        factory.setJpaProperties(jpaProperties);

        return factory;
    }

    @Bean(name="csdtEntityManager")
    public EntityManager csdtEntityManager(
            @Qualifier("csdtEntityManagerFactory") LocalContainerEntityManagerFactoryBean csdtEntityManagerFactory)
    {
        return Objects.requireNonNull(csdtEntityManagerFactory.getObject()).createEntityManager();
    }

    @Primary
    @Bean(name="csdtMetamodel")
    public Metamodel metaModel(@Qualifier("csdtEntityManagerFactory")
                                  LocalContainerEntityManagerFactoryBean csdtEntityManagerFactory) {
        return csdtEntityManagerFactory.getNativeEntityManagerFactory().getMetamodel();
    }


    @Primary
    @Bean(name="csdtTransactionManager")
    public PlatformTransactionManager csdtTransactionManager(
            LocalContainerEntityManagerFactoryBean csdtEntityManagerFactory) {
        EntityManagerFactory factory = csdtEntityManagerFactory.getObject();
        assert factory != null;
        return new JpaTransactionManager(factory);
    }

    @Primary
    @Bean
    public DataSourceInitializer csdtDataSourceInitializer(
            @Qualifier("csdtDataSource") DataSource csdtDataSource) {
        DataSourceInitializer dataSourceInitializer = new DataSourceInitializer();
        dataSourceInitializer.setDataSource(csdtDataSource);
        ResourceDatabasePopulator databasePopulator = new ResourceDatabasePopulator();
//        databasePopulator.addScript(new ClassPathResource("security-data.sql"));
        dataSourceInitializer.setDatabasePopulator(databasePopulator);
        dataSourceInitializer.setEnabled(env.getProperty("spring.datasource.scdt.initialize", Boolean.class, false));
        return dataSourceInitializer;
    }
}
