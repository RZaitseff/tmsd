package ru.sbrf.report.csv;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;


@Service
public class Reader {

    @Value("${CSV_FIELDS_DELIMITER}")
    private static final String delimiter = ",";

    public static String[] readCsvHeader(String filePath) throws IOException {
        String[] columns = null;
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String header = br.readLine();
            if (header != null) {
                columns = header.split(delimiter);
            }
            return columns;
        }
    }

    public static String[][] readCsvFirstRow(String filePath) throws IOException {
        String[] columns = null;
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String header = br.readLine();
            String[] headers = null;
            if (header != null) {
                headers = header.split(delimiter);
            }
            String row = br.readLine();
            if (row != null) {
                columns = row.split(delimiter);
            }
            assert headers != null;
            String[][] answer = new String[2][headers.length];
            answer[0] = headers;
            answer[1] = columns;
            return answer;
        }
    }

    public static void main(String[] argv) throws IOException {
        String[][] rows = readCsvFirstRow("CSV/ReplicaDA.2024.01.csv");
        for (int i = 0; i < rows[0].length; i++)
            System.out.println(rows[0][i] + ": " + rows[1][i]);
    }

}
